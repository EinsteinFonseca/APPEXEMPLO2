﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppFormsExemplo2.Formularios;
using AppFormsExemplo2.Formularios.RegrasDeNegocio;

namespace AppFormsExemplo2.Formularios
{
    public partial class FormSoma : Form
    {
        public FormSoma()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FormSoma_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Calculadora calculadora = new Calculadora();
            calculadora.Valor1 = Convert.ToDouble(Valor1.Text);
            calculadora.Valor2 = Convert.ToDouble(Valor2.Text);
            calculadora.CalcularSoma();// processamento
            calculadora.CalcularMultiplicacao();
            Total.Text = calculadora.Total.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
