﻿namespace AppFormsExemplo2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BTmultiplicacao = new System.Windows.Forms.Button();
            this.BTsoma = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.SuspendLayout();
            // 
            // BTmultiplicacao
            // 
            this.BTmultiplicacao.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.BTmultiplicacao.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTmultiplicacao.ForeColor = System.Drawing.SystemColors.ControlText;
            this.BTmultiplicacao.Location = new System.Drawing.Point(230, 286);
            this.BTmultiplicacao.Name = "BTmultiplicacao";
            this.BTmultiplicacao.Size = new System.Drawing.Size(257, 37);
            this.BTmultiplicacao.TabIndex = 0;
            this.BTmultiplicacao.Text = "CALCULAR MULTIPLICAÇÃO";
            this.BTmultiplicacao.UseVisualStyleBackColor = false;
            this.BTmultiplicacao.Click += new System.EventHandler(this.button1_Click);
            // 
            // BTsoma
            // 
            this.BTsoma.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.BTsoma.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTsoma.ForeColor = System.Drawing.SystemColors.ControlText;
            this.BTsoma.Location = new System.Drawing.Point(230, 76);
            this.BTsoma.Name = "BTsoma";
            this.BTsoma.Size = new System.Drawing.Size(257, 33);
            this.BTsoma.TabIndex = 1;
            this.BTsoma.Text = "CALCULAR SOMA";
            this.BTsoma.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BTsoma.UseVisualStyleBackColor = false;
            this.BTsoma.Click += new System.EventHandler(this.button2_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AppFormsExemplo2.Properties.Resources.PI1;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BTsoma);
            this.Controls.Add(this.BTmultiplicacao);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTmultiplicacao;
        private System.Windows.Forms.Button BTsoma;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    }
}

