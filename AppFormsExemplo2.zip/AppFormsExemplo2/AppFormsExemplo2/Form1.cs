﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using AppFormsExemplo2.Formularios;

namespace AppFormsExemplo2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormSoma form = new FormSoma();
            form.ShowDialog();// chamar o form soma
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Multiplicacao form = new Multiplicacao();
            form.ShowDialog(); /// TERMINAR DE CONFIGURAR MULTIPLICAÇÃO 
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
